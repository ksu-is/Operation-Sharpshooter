## What next?

- Can you put the game into a loop (you'll need to remove the `exit()`), so that the LED comes on again?
- Can you add scores for both players that accumulate over a number of rounds, and displays the players' total scores?
- How about adding in a timer, to work out how long it took the players to press the button after the LED turned off?

