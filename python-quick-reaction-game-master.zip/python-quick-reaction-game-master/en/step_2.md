## What you will need

### Hardware

* 1 x Breadboard
* 1 x LED
* 1 x 330 ohm Resistor
* 4 x Male-to-female jumper wires
* 2 x Male-to-male jumper wires
* 2 x Tactile push buttons